<?php

namespace Doctrine\DBAL\Driver\IBMDB2;

final class Connection extends DB2Connection
{
}
