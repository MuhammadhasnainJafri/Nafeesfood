<?php

namespace Doctrine\DBAL\Driver\SQLSrv;

final class Connection extends SQLSrvConnection
{
}
