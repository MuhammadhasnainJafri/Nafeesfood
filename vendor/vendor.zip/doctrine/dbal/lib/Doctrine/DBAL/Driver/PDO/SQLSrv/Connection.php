<?php

namespace Doctrine\DBAL\Driver\PDO\SQLSrv;

use Doctrine\DBAL\Driver\PDOSqlsrv;

final class Connection extends PDOSqlsrv\Connection
{
}
