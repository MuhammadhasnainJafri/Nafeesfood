<?php

namespace Doctrine\DBAL\Driver\Mysqli;

final class Statement extends MysqliStatement
{
}
