Hello!

The new version {{ $newVersion }} is available.

Kind regards
