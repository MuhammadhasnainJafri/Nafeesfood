<?php

use PHPUnit\Framework\TestCase;

class SetEnvTest extends TestCase
{
    public function testBasicTest(): void
    {
        self::assertTrue(true);
    }
}
