<?php

declare(strict_types=1);

namespace dacoto\SetEnv\Exceptions;

use Exception;

class KeyNotFoundException extends Exception
{

}
