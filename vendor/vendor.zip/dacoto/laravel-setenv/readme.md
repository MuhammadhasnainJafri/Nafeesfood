# Laravel .env editor

![GitHub Workflow Status (branch)](https://img.shields.io/github/workflow/status/dacoto/laravel-setenv/CI/master)
![GitHub](https://img.shields.io/github/license/dacoto/laravel-setenv)
![GitHub release (latest by date)](https://img.shields.io/github/v/release/dacoto/laravel-setenv)

A .env editor for Laravel 7.x and higher.
